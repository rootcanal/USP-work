int getevent(int eventnumber);
int getnumevents(void);
int getrunning(void);
long getvalue(int n);
int removetop(void);
int timerinit(void);
void timerstart(int n, long interval);
void timerstop(int n);
void waitforevent(void);
