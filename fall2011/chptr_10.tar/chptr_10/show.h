void showinit(int maxtimers);
void show(int traceflag, const char *msg, long val1, long val2, int blockedflag);
